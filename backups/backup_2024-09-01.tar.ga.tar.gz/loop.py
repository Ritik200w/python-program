list_of_cloud = ["aws","Gcp","azure","utho","digital ocean"]
print(list_of_cloud)

list_of_cloud.append("IBM")
print(list_of_cloud)


print(len(list_of_cloud))


list_of_cloud.insert(0,"ritikcloud")
print(list_of_cloud)

#Iterarion of a list
for cloud in list_of_cloud:
    print(cloud)



for i in range(0,10):
    print(i)